# Local Deployement File Storage

This folder stores the data files required for building local deployement.

## File List

- Image for the card. (.jpeg/.png)
- Text for the scroll message. (.txt)
