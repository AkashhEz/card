export const soon = {
  title: "Come Back Later...",
  body: `<br />
    <h1>Hi, you came too early</h1>
    <br /><br /><br />
    <p>
    
        You need to be patient
    </p>`,
};

export const late = {
  title: "See you next time...",
  body: `<br />
    <h1>The party was over</h1>
    <br /><br /><br />
    <p>
        Yes, my gift for you is kinda simple, cheap, and weird ? &#128534<br>
        but. It's only for you. &#128150
    </p>
`,
};
